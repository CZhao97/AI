g++ a5.cpp (to complie the mcts algorithm)
g++ db.cpp (to complie the heuristic algorithm)

./a.out (to run it in terminal)