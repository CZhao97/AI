def check_teams(graph,csp_sol):
    for i, value in graph.items():
        temp = csp_sol[i]
        for val in value:
            if temp == csp_sol[val]:
                return False
    return True
